from django.conf.urls import url, include
from . import views


urlpatterns = [
    url(r'^$', views.enter, name='enter' ),
    url(r'^enter$', views.enter, name='enter' ),
    url(r'^logout$', views.logout, name='logout' ),
    url(r'^teacher$', views.teacher, name='teacher' ),
    url(r'^research$', views.research, name='research' ),
    url(r'^diplom$', views.diplom, name='diplom' ),
    url(r'^student$', views.student, name='student' ),
    url(r'^view_list$', views.view_list, name='view_list' ),
    url(r'^change$', views.change_teach, name='change_teach' ) 
]
