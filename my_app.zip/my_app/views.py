from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.template.response import TemplateResponse
from .models import users, research as res, diplom as db_dip, detail
from .forms import ProfileForm
from django.conf import settings
from django.conf.urls.static import static
from django.core.files import File

def enter(request):
	if 'code'  in request.session:
		if len(request.POST.get('code', ''))==6:
			return teacher(request)
		elif len(request.POST.get('code', ''))==10:	
			return student(request)

	if request.method == 'POST':  
		tmp=request.POST.get('tmp', '')
		
		if tmp=='logup':   
			try:
				n_mail=request.POST.get('mail', '')
				n_code=request.POST.get('code', '')
				n_pass=request.POST.get('password', '')
				n_lname=request.POST.get('lname', '')
				n_fname=request.POST.get('fname', '')
				phone=request.POST.get('phone', '')
				new_users=users.objects.create(mail=n_mail, code=n_code, password=n_pass, lname=n_lname, fname=n_fname, phone=phone )			

				return TemplateResponse(request, 'enter.html', {'log_up_sms': 'Бүртгэл амжилттай болсон. Та нэвтэрч орон уу'})
			except Exception as e:
				if str(e).find('code')>-1:
					return TemplateResponse(request, 'enter.html', {'log_up_sms': 'Код давхардсан байна'})
				else:
					return TemplateResponse(request, 'enter.html', {'log_up_sms': 'Алдаа гарсан'})
		elif tmp=='login':
			try:
				login_users=users.objects.get(code=request.POST.get('code', ''),  password=request.POST.get('password', ''))
				request.session['code']=request.POST.get('code', '')
				if len(request.POST.get('code', ''))==6:
					return redirect('teacher')
				elif len(request.POST.get('code', ''))==10:	
					return redirect('student')
			except Exception as e:
				return TemplateResponse(request, 'enter.html', {'message': 'Алдаа гарсан'})

		else:
			return render(request, 'enter.html')
	else:
		return render(request, 'enter.html')

def logout(request, ):
	if 'code' in request.session:
		del request.session['code']
		return redirect('enter')
	else:
		return redirect('enter')


# parts for teacher
def teacher(request):
	if 'code' not in request.session:
		return enter(request)
	if len(request.session['code'])==10:	
		return student(request)
	user=users.objects.get(code=request.session['code'])
	try:
		researchs=res.objects.all().filter(user_id=request.session['code'])
	except Exception as e:
		error=e
	if user.degree== None or user.degree=='':	
		degree='no'	
		try:
			if request.method == 'POST':
				user.degree=request.POST.get('degree', '')
				user.save()	
		except Exception as e:
			print(e)
	else:
		degree=user.degree

	img='dist/img/default.png'
	if user.avatar:
		img=user.avatar

	context = {
		'image':'dist/img/default.png', 
		'status':'Багш',		
		'user':user,
		'researchs':researchs, 
		'degree':degree,
		'profile':'True' 
	}

	return TemplateResponse(request, 'teacher.html', context)


def change_teach(request):
	if 'code' not in request.session:
		return enter(request)
	user=users.objects.get(code=request.session['code'])
	try:
		researchs=res.objects.all().filter(user_id=request.session['code'])
	except Exception as e:
		error=e
	if user.degree== None or user.degree=='':	
		degree='no'	
		try:
			if request.method == 'POST':
				user.degree=request.POST.get('degree', '')
				user.save()	
		except Exception as e:
			print(e)
	else:
		degree=user.degree



	if request.method == "POST":
		if request.FILES['image']:
			up_file = request.FILES['image']
			destination = open('/home/nuna/thesis/media/my_app/static/avatar/'+ up_file.name , 'wb')
			for chunk in up_file.chunks():
			    destination.write(chunk)
			destination.close()
			user.avatar='my_app/static/avatar/'+up_file.name
			user.save()
		user.mail=request.POST.get('mail', '')
		user.lname=request.POST.get('lname', '')
		user.fname=request.POST.get('name', '')
		user.phone=request.POST.get('phone', '')
		user.save()
		return redirect('teacher')

	img='dist/img/default.png'
	if user.avatar:
		img=user.avatar
	
	if len(request.session['code'])==6:
		context = {
		'status':'Багш',		
		'user':user,
		'researchs':researchs, 
		'degree':degree, 
		'change':'True' ,
		'profile':'True' 
		}
		return TemplateResponse(request, 'teacher.html', context)
	elif len(request.session['code'])==10:	
		context = {
		'status':'Оюутан',		
		'user':user,
		'change':'True' ,
		'profile':'True' 
		}
		return TemplateResponse(request, 'student.html', context)
	


def research(request):
	

	if 'code' not in request.session:
		return enter(request)
	if len(request.session['code'])==10:	
		return student(request)
	user=users.objects.get(code=request.session['code'])
	img='dist/img/default.png'
	if user.avatar:
		img=user.avatar

	try:
		researchs=res.objects.all().filter(user_id=request.session['code'])
	except Exception as e:
		error=e
	add_sms=''
	if request.method == 'POST':  
		tmp=request.POST.get('sudalgaa', '')
		if tmp=='sudalgaa':
			try:
				n_topic=request.POST.get('topic', '')
				n_note=request.POST.get('note', '')
				new_users=res.objects.create(user_id=user, topic=n_topic, note=n_note)			

				add_sms='амжилттай болсон'
			except Exception as e:
				print(e)
	context = {
		'image':'dist/img/default.png', 
		'status':'Багш' , 
		'user':user,
		'research':'True',
		'researchs':researchs
	}
	
	return TemplateResponse(request, 'teacher.html', context)



def diplom(request):
	if 'code' not in request.session:
		return enter(request)
	if len(request.session['code'])==10:	
		return student(request)
	user=users.objects.get(code=request.session['code'])
	
	add_sms=''

	try:
		diploms=db_dip.objects.all().filter(user_id=request.session['code'], diplom=True)
	except Exception as e:
		error=e

	try:
		tosols=db_dip.objects.all().filter(user_id=request.session['code'], tosol=True)
	except Exception as e:
		error=e
	try:
		researchs=res.objects.all().filter(user_id=request.session['code'])
	except Exception as e:
		error=e

	if request.method == 'POST':  
		tmp=request.POST.get('dip', '')
		if tmp=='dip':
			try:
				n_topic=request.POST.get('topic', '')
				n_note=request.POST.get('note', '')
				n_diplom=request.POST.get('diplom', '')
				n_tosol=request.POST.get('tosol', '')
				if n_diplom and n_tosol:
					new_dip=db_dip.objects.create(user_id=user, topic=n_topic, note=n_note, diplom=True, tosol=True)
				elif n_diplom:
					new_dip=db_dip.objects.create(user_id=user, topic=n_topic, note=n_note, diplom=True)
				elif n_tosol:
					new_dip=db_dip.objects.create(user_id=user, topic=n_topic, note=n_note, tosol=True)
				else:
					context = {
						'image':'dist/img/default.png', 
						'status':'Багш' , 
						'diplom':'True',
						'error_dip':'Алдаа гарсан'
					}
					
					return TemplateResponse(request, 'teacher.html', context)					
				#new_users=res.objects.create(user_id=user, topic=n_topic, note=n_note)			

				add_sms='амжилттай болсон'
			except Exception as e:
				print(e)
	context = {
		'image':'dist/img/default.png', 
		'status':'Багш' , 
		'user':user,
		'diplom':'True',
		'diploms':diploms,
		'tosols':tosols,
		'researchs':researchs
	}
	
	return TemplateResponse(request, 'teacher.html', context)



def student(request):
	if 'code' not in request.session:
		return enter(request)
	if len(request.session['code'])==6:
		return teacher(request)
	user=users.objects.get(code=request.session['code'])
	context = {
		'image':'dist/img/default.png',
		'user':user, 
		'status':'Оюутан',
		'profile':'True'  
	}

	return TemplateResponse(request, 'student.html', context)

def view_list(request):
	if 'code' not in request.session:
		return enter(request)
	if len(request.session['code'])==6:
		return teacher(request)
	user=users.objects.get(code=request.session['code'])
	try:
		diploms=db_dip.objects.all().filter( diplom=True)
		
	except Exception as e:
		error=e

	try:
		tosols=db_dip.objects.all().filter(tosol=True)
	except Exception as e:
		error=e
	try:
		researchs=res.objects.all()
	except Exception as e:
		error=e

	if request.method == 'GET':  
		if request.GET:

			choose=db_dip.objects.get(d_id=request.GET['id'])
			
			context = {
				'user':user,
				'image':'dist/img/default.png', 
				'status':'Оюутан', 
				'diploms':diploms,
				'tosols':tosols,
				'researchs':researchs,
				'choose':choose
			}

			return TemplateResponse(request, 'student.html', context)		


	context = {
		'user':user,
		'image':'dist/img/default.png', 
		'status':'Оюутан', 
		'diploms':diploms,
		'tosols':tosols,
		'researchs':researchs
	}

	return TemplateResponse(request, 'student.html', context)



